 Askeri Uçak Sistemi ✈️

Bu proje, farklı türde sivil, askeri ve kargo uçaklarının **Nesne Yönelimli Programlama (OOP)** ilkeleriyle modellenmesini sağlar.  
Python'da **abstract class (ABC)** kullanılarak ortak özellikler tanımlanmış, alt sınıflar ile özelleştirilmiştir.

🚀 Özellikler
- ✈️ Avcı Uçağı → Hızlı manevra ve füze sistemleri
- 🚁 Askerî Helikopter → Radar, zırh seviyesi, silah sistemleri ve özel güzergâh yönetimi
- 💣 Bombardıman Uçağı → Yüksek bomba taşıma kapasitesi
- 📦 Nakliye Uçağı → Ağır yük ve personel taşıma
- 🔭 Keşif Uçağı → Gelişmiş kamera ve gözetleme sistemleri
- 👨‍👩‍👧‍👦 Yolcu Uçağı → Sivil taşımacılık, yüksek yolcu kapasitesi
- 📮 Kargo Uçağı → Ticari kargo ve lojistik taşımacılık
- 🛰️ Kontrol Kulesi → Tüm uçakların ve helikopterlerin merkezi yönetimi

