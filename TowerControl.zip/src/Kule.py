from abc import ABC, abstractmethod


class Ucak(ABC):
    ucak_sayisi = 0
    ucaklar = []
    def __init__(self, _ucak_numara, __marka_model, __kapasite, __ucak_kutle, __depo_doluluk_orani, __menzil):
        self.ucak_numara = _ucak_numara
        self.marka_model = __marka_model
        self.kapasite = __kapasite
        self.ucak_kutle = __ucak_kutle
        self.depo_doluluk_orani = __depo_doluluk_orani
        self.menzil = __menzil
        Ucak.ucak_sayisi += 1
        Ucak.ucaklar.append(self)

    @abstractmethod
    def _bilgileri_goster(self):
        return (f"Uçak No: {self.ucak_numara}, Marka-Model: {self.marka_model}, "
                f"Kapasite: {self.kapasite}, Uçak Kütlesi: {self.ucak_kutle} kg, "
                f"Depo Doluluk: %{self.depo_doluluk_orani}, Menzil: {self.menzil} km")
    
    @classmethod
    def ucak_bilgilerini_goster(cls, ucak_numara):
        for ucak in cls.ucaklar:
            if ucak.ucak_numara == ucak_numara:
                return ucak._bilgileri_goster()
        return "Uçak bulunamadi."

    @staticmethod
    def Ucak_Sayisi():
        return f"Oluşturulan toplam uçak sayisi: {Ucak.ucak_sayisi}"

class YolcuUcagi(Ucak):
    ucak_sayisi = 0
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, yolcu_kapasitesi, koltuk_duzeni):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil)
        # Ucak özelliklerini kendimiz tanımlıyoruz.
        self.yolcu_kapasitesi = yolcu_kapasitesi
        self.koltuk_duzeni = koltuk_duzeni
        self.guzergahlar = []
        YolcuUcagi.ucak_sayisi += 1
        

    def _guzergah_ekle(self, guzergah):
        self.guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.guzergahlar]

    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() +
                f", Yolcu Kapasitesi: {self.yolcu_kapasitesi}, Koltuk Düzeni: {self.koltuk_duzeni}, "
                f"Güzergahlar: {', '.join(self._guzergah_goster())}")
    
    @staticmethod
    def Ucak_Sayisi():
        return f"Oluşturulan toplam uçak sayisi: {YolcuUcagi.ucak_sayisi}"

class KargoUcagi(Ucak):
    ucak_sayisi = 0
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, kargo_kapasite):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil)
        self.kargo_kapasite = kargo_kapasite
        self.kargo_guzergahlar = []
        KargoUcagi.ucak_sayisi += 1

    def _guzergah_ekle(self, guzergah):
        self.kargo_guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.kargo_guzergahlar]

    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + 
                f"Kargo Kapasitesi: {self.kargo_kapasite}, Güzergahlar: {', '.join(self._guzergah_goster())}")
    
    @staticmethod
    def Ucak_Sayisi():
        return f"Oluşturulan toplam uçak sayisi: {KargoUcagi.ucak_sayisi}"

class AskeriUcak(Ucak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil)
        self.silah_kapasite = silah_kapasite
        self.personel_kapasite = personel_kapasite
        self.subay_kapasite = subay_kapasite
        self.askeri_guzergahlar = []

    def _guzergah_ekle(self, guzergah):
        self.askeri_guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.askeri_guzergahlar]

    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + 
                f", Silah Kapasitesi: {self.silah_kapasite}, Personel Kapasitesi: {self.personel_kapasite}, "
                f"Subay Kapasitesi: {self.subay_kapasite}, Güzergahlar: {', '.join(self._guzergah_goster())}")
    
class AvciUcagi(AskeriUcak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite,
            radar_kapasitesi, maksimum_hiz, manevra_kabiliyeti, stealth_teknolojisi, silah_sistemleri):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite)
        self.radar_kapasitesi = radar_kapasitesi
        self.maksimum_hiz = maksimum_hiz
        self.manevra_kabiliyeti = manevra_kabiliyeti
        self.stealth_teknolojisi = stealth_teknolojisi
        self.silah_sistemleri = silah_sistemleri
        self.ozel_askeri_guzelgahlar = []
        #radar_kapasitesi: Uçağın radarının algılayabileceği maksimum mesafe.
        #maksimum_hiz: Uçağın ulaşabileceği en yüksek hız (örneğin, Mach birimi ile).
        #manevra_kabiliyeti: Uçağın yüksek hızlarda gerçekleştirebileceği dönüş ve manevra yetenekleri.
        #stealth_teknolojisi: Uçağın radar görünmezlik özellikleri, düşük radar izi gibi avantajları.
        #silah_sistemleri: Uçakta kullanılabilir silah sistemlerinin türleri, örneğin füzeler, makineli tüfekler.
    def _guzergah_ekle(self, guzergah):
        self.ozel_askeri_guzelgahlar.append(guzergah)
    
    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.ozel_askeri_guzelgahlar]
    
    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + f"Radar Kapasitesi: {self.radar_kapasitesi}",f"Maksimum Hiz: {self.maksimum_hiz}",
                f"Manevra Kabiliyeti: {self.manevra_kabiliyeti}",f"Stealth(Gizlilik) Teknolojisi: {self.stealth_teknolojisi}",
            f"Silah Sistemleri: {self.silah_sistemleri}",f"Özel Askeri Guzergahlar: {', '.join(self._guzergah_goster())}")

class AskeriHelikopter(AskeriUcak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite,
                radar_kapasitesi,zirh_seviyesi,maksimum_kalkis_agirligi,silah_sistemleri,yuk_tasima_kapasitesi,havada_kalis_suresi):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite)
        self.radar_kapasitesi = radar_kapasitesi
        self.zirh_seviyesi = zirh_seviyesi
        self.maksimum_kalkis_agirliği = maksimum_kalkis_agirligi
        self.silah_sistemleri = silah_sistemleri
        self.yuk_tasima_kapasitesi = yuk_tasima_kapasitesi
        self.havada_kalis_suresi = havada_kalis_suresi
        self.ozel_askeri_guzergahlar = []
        # Helikopterin radar algılama menzili
        # Helikopterin zırh seviyesi (koruma derecesi)
        # Helikopterin tam yük ile kalkabileceği maksimum ağırlık
        # Kullanılabilir silah sistemleri listesi veya türü
        # Helikopterin taşıyabileceği yük kapasitesi
        # Helikopterin yakıt kapasitesine göre havada kalış süresi     

    def _guzergah_ekle(self, guzergah):
        self.ozel_askeri_guzergahlar.append(guzergah)
    
    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.ozel_askeri_guzergahlar]
    
    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + f"Radar Kapasitesi: {self.radar_kapasitesi}",f"Zirh Seviyesi: {self.zirh_seviyesi}",
        f"Maksimum Kalkis Agirligi: {self.maksimum_kalkis_agirliği}",f"Silah Sistemleri: {self.silah_sistemleri}",
        f"Yuk Tasima Kapasitesi: {self.yuk_tasima_kapasitesi}",f"Havada Kalis Suresi: {self.havada_kalis_suresi}",
        f"Ozel Askeri Guzergahlar(Helikopter): {', '.join(self._guzergah_goster())}")
    
class BombardimanUcagi(AskeriUcak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite,
                bomba_tasima_kapasitesi,radar_kapasitesi,zirh_seviyesi,karsi_tedbir_sistemleri,uzun_menzilli_vurus_kabiliyeti,maksimum_hiz):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite)

        self.bomba_tasima_kapasitesi = bomba_tasima_kapasitesi  # Uçağın taşıyabileceği bomba miktarı veya ağırlığı
        self.radar_kapasitesi = radar_kapasitesi  # Uçağın radar algılama menzili
        self.zirh_seviyesi = zirh_seviyesi  # Uçağın düşman ateşine karşı koruma seviyesi
        self.karsi_tedbir_sistemleri = karsi_tedbir_sistemleri  # Radar veya füze savunma sistemleri
        self.uzun_menzilli_vurus_kabiliyeti = uzun_menzilli_vurus_kabiliyeti  # Uçağın uzun mesafeden hassas vuruş yapma yeteneği
        self.maksimum_hiz = maksimum_hiz  # Uçağın ulaşabileceği maksimum hız
        self.ozel_askeri_guzergahlar = []

    def _guzergah_ekle(self, guzergah):
        self.ozel_askeri_guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.ozel_askeri_guzergahlar]

    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + f"Bomba Tasima Kapasitesi: {self.bomba_tasima_kapasitesi}",f"Radar Kapasitesi: {self.radar_kapasitesi}",
                f"Zirh Seviyesi: {self.zirh_seviyesi}",f"Karsi Tedbir Sistemleri: {self.karsi_tedbir_sistemleri}",f"Uzun Menzilli Vurus Kabiliyeti: {self.uzun_menzilli_vurus_kabiliyeti}",
                f"Maksismum Hiz: {self.maksimum_hiz}",f"Ozel Askeri Guzergahlar: {', '.join(self._guzergah_goster())}")

class NakliyeUcagi(AskeriUcak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite
                ,arac_tasima_kapasitesi,muhimmat_tasima_kapasitesi,yakit_tasima_kapasitesi,tibbi_malzeme_kapasitesi,
                gida_ve_ikmal_kapasitesi,insani_yardim_kapasitesi,yedek_parca_kapasitesi,maksimum_hiz,iniş_kalkis_mesafesi,zirh_seviyesi):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite)
        self.arac_tasima_kapasitesi = arac_tasima_kapasitesi  # Askeri araç ve ekipman taşıma kapasitesi
        self.muhimmat_tasima_kapasitesi = muhimmat_tasima_kapasitesi  # Mühimmat taşıma kapasitesi
        self.yakit_tasima_kapasitesi = yakit_tasima_kapasitesi  # Ek yakıt taşıma kapasitesi
        self.tibbi_malzeme_kapasitesi = tibbi_malzeme_kapasitesi  # Tıbbi malzeme ve yaralı taşıma kapasitesi
        self.gida_ve_ikmal_kapasitesi = gida_ve_ikmal_kapasitesi  # Gıda ve diğer ikmal malzemeleri taşıma kapasitesi
        self.insani_yardim_kapasitesi = insani_yardim_kapasitesi  # İnsani yardım malzemeleri taşıma kapasitesi
        self.yedek_parca_kapasitesi = yedek_parca_kapasitesi  # Uçak ve helikopter yedek parça taşıma kapasitesi
        self.maksimum_hiz = maksimum_hiz  # Uçağın ulaşabileceği maksimum hız
        self.iniș_kalkis_mesafesi = iniş_kalkis_mesafesi  # Uçağın iniş ve kalkış yapabilmesi için gerekli mesafe
        self.zirh_seviyesi = zirh_seviyesi  # Uçağın zırh koruma seviyesi
        self.ozel_askeri_guzergahlar = []

    def _guzergah_ekle(self, guzergah):
        self.ozel_askeri_guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah.rota_adi for guzergah in self.ozel_askeri_guzergahlar]
    
    def _bilgileri_goster(self):
        return (super()._bilgileri_goster() + f"Arac Tasima Kapasitesi: {self.arac_tasima_kapasitesi}",f"Muhimmat Tasima Kapasitesi: {self.muhimmat_tasima_kapasitesi}",
                f"Yakit Tasima Kapasitesi: {self.yakit_tasima_kapasitesi}",f"Tibbi Malzeme Kapasitesi: {self.tibbi_malzeme_kapasitesi}",
                f"İnsani Yardim Kapasite: {self.insani_yardim_kapasitesi}",f"Yedek Parca Kapasite: {self.yedek_parca_kapasitesi}",f"Maksimum Hiz: {self.maksimum_hiz}",
                f"Pist İnis-Kalkis Mesafesi: {self.iniș_kalkis_mesafesi}",f"Zirh Seviyesi: {self.zirh_seviyesi}",f"Ozel Askeri Guzergahlar: {', '.join(self._guzergah_goster())}")
    
class KesifUcagi(AskeriUcak):
    def __init__(self, _ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite, personel_kapasite, subay_kapasite,
                radar_kapasitesi,sensor_kapasitesi,veri_toplama_kapasitesi,uzun_menzilli_görüntü_kabiliyeti):
        super().__init__(_ucak_numara, marka_model, kapasite, ucak_kutle, depo_doluluk_orani, menzil, silah_kapasite,personel_kapasite, subay_kapasite)
        self.radar_kapasitesi = radar_kapasitesi  # Radar sistemi kapasitesi
        self.sensor_kapasitesi = sensor_kapasitesi # Termal, kızılötesi ve diğer keşif sensörleri kapasitesi.
        self.veri_toplama_kapasitesi = veri_toplama_kapasitesi  # Verinin toplamak için kullanılacak toplam kapasite
        self.uzun_menzilli_görüntü_kabiliyeti = uzun_menzilli_görüntü_kabiliyeti # Menzil boyutu ve ona orantılı görüntü çözünürlüğü
        self.ozel_askeri_guzergahlar = []
    
    def _guzergah_ekle(self, guzergah):
        self.ozel_askeri_guzergahlar.append(guzergah)

    def _guzergah_goster(self):
        return [guzergah for guzergah in self.ozel_askeri_guzergahlar]
    
    def _bilgileri_goster(self):
        # super()._bilgileri_goster() sonucu dönen değeri string ile birleştirerek, tuple yerine düz bir string döndürebilirsiniz
        return (super()._bilgileri_goster() +
            f"Radar Kapasitesi: {self.radar_kapasitesi}",
            f"Sensor Kapasitesi: {self.sensor_kapasitesi}",
            f"Veri Toplama Kapasitesi: {self.veri_toplama_kapasitesi}",
            f"Uzun Menzilli Görüntü Kabiliyeti: {self.uzun_menzilli_görüntü_kabiliyeti}")
        
class Guzergah:
    def __init__(self, rota_adi,mesafe, guzergah_turu):
        self.rota_adi = rota_adi
        self.mesafe = mesafe
        self.guzergah_turu = guzergah_turu
    


class HavaDurumu:
    def __init__(self, hava_durumu, yan_ruzgar_hizi, kuyruk_ruzgar_hizi, bas_ruzgar_hizi, sicaklik, yagis_durumu, gorunurluk, nem_orani):
        self.hava_durumu = hava_durumu
        self.hava_durumlari = ["Yagisli", "Bulutlu", "Gunesli", "Sisli", "Firtina", "Karli"]
        self.yan_ruzgar_hizi = yan_ruzgar_hizi
        self.kuyruk_ruzgar_hizi = kuyruk_ruzgar_hizi
        self.bas_ruzgar_hizi = bas_ruzgar_hizi
        self.sicaklik = sicaklik
        self.yagis_durumu = yagis_durumu
        self.gorunurluk = gorunurluk
        self.nem_orani = nem_orani

    def _durumu_goster(self):
        return (f"Hava Durumu: {self.hava_durumu}, Yanal Rüzgar Hizi: {self.yan_ruzgar_hizi} km/sa, "
                f"Kuyruk Rüzgari Hizi: {self.kuyruk_ruzgar_hizi} km/sa, Baş Rüzgari: {self.bas_ruzgar_hizi} km/sa, "
                f"Sicaklik: {self.sicaklik}°C, Yağiş Durumu: {self.yagis_durumu}, "
                f"Hava Görünürlüğü: {self.gorunurluk}, Nem Orani: %{self.nem_orani}")


class KontrolKulesi:
    def __init__(self):
        self.ucuslar = []
        self.ucaklar = []
        self.kargo_ucaklari_takvimi = []
        self.yolcu_ucaklari_takvimi = []
        self.tum_ucuslar = []  # Tüm uçuşları tutacak liste

    def _zaman_guncelle(self, zaman, dakika_artis):
        # Saat ve dakika güncellemesi
        saat, dakika = zaman[3], zaman[4]
        dakika += dakika_artis
        saat += dakika // 60
        dakika %= 60

        # Yeni tarihi hesaplamak gerekirse (bugünlük basit bir hesaplama yapıyoruz)
        return (zaman[0], zaman[1], zaman[2], saat, dakika)

    def _cakisma_kontrol(self, yeni_kalkis, yeni_inis, tum_ucuslar, ucus_tipi):
        # Kalkış ve iniş zamanlarını saniye bazında hesapla
        yeni_kalkis_saniye = yeni_kalkis[3] * 60 + yeni_kalkis[4]
        yeni_inis_saniye = yeni_inis[3] * 60 + yeni_inis[4]

        for ucak in tum_ucuslar:
            mevcut_kalkis_saniye = ucak["Kalkis"][3] * 60 + ucak["Kalkis"][4]
            mevcut_inis_saniye = ucak["İnis"][3] * 60 + ucak["İnis"][4]

            # Çakışma kontrolü
            if (mevcut_kalkis_saniye <= yeni_kalkis_saniye < mevcut_inis_saniye) or \
               (mevcut_kalkis_saniye < yeni_inis_saniye <= mevcut_inis_saniye) or \
               (yeni_kalkis_saniye <= mevcut_kalkis_saniye and yeni_inis_saniye >= mevcut_inis_saniye):
                # Çakışma durumunda saatleri güncelle
                dakika_artis = 20 if ucus_tipi == "Yolcu" else 40
                yeni_kalkis = self._zaman_guncelle(yeni_kalkis, dakika_artis)
                yeni_inis = self._zaman_guncelle(yeni_inis, dakika_artis)
                # Yeni zamanlarla tekrar kontrol yap
                return self._cakisma_kontrol(yeni_kalkis, yeni_inis, tum_ucuslar, ucus_tipi)
        # Çakışma yoksa güncel zamanları döndür
        return yeni_kalkis, yeni_inis

    def _ucus_ekle(self, ucus_tipi, ucak, guzergah, kalkis, inis):
        # Çakışma kontrolü ve zaman güncelleme
        yeni_kalkis, yeni_inis = self._cakisma_kontrol(kalkis, inis, self.tum_ucuslar, ucus_tipi)

        # Uçuş bilgilerini uygun listeye ekleme
        ucus = {
            'Ucak': ucak,
            'Guzergah': guzergah,
            'Kalkis': yeni_kalkis,
            'İnis': yeni_inis
        }

        if ucus_tipi == "Yolcu":
            self.yolcu_ucaklari_takvimi.append(ucus)
        elif ucus_tipi == "Kargo":
            self.kargo_ucaklari_takvimi.append(ucus)
        else:
            print("Geçersiz uçuş tipi!")

        # Aynı zamanda tüm uçuşları da kaydet
        self.tum_ucuslar.append(ucus)
        print(f"{ucus_tipi} uçuşu başariyla eklendi: {ucak} - {guzergah}, Kalkiş: {ucus['Kalkis']}, İniş: {ucus['İnis']}")

    def _ucuslari_goster(self):
        print("\nTüm Uçuşlar:")
        for ucus in self.tum_ucuslar:
            kalkis_tarihi = f"{ucus['Kalkis'][0]:04d}-{ucus['Kalkis'][1]:02d}-{ucus['Kalkis'][2]:02d}"
            kalkis_saati = f"{ucus['Kalkis'][3]:02d}:{ucus['Kalkis'][4]:02d}"
            inis_saati = f"{ucus['İnis'][3]:02d}:{ucus['İnis'][4]:02d}"
            print(f"{ucus['Ucak']} - {ucus['Guzergah']}: Kalkiş: {kalkis_tarihi} {kalkis_saati}, İniş: {inis_saati}")
        
    def _ucak_ekle(self, ucak):
        self.ucaklar.append(ucak)
        print(f"{ucak.ucak_numara} numarali uçak eklendi.")
    
    def __inis_izin_ver(self, ucak):
        print(f"{ucak.ucak_numara} icin inis izni verildi.")
    
    def __kalkis_izni_ver(self, ucak):
        print(f"{ucak.ucak_numara} icin kalkis izni verildi.")
    
    def ucak_arama(self, ucak_numara):
        for ucak in self.ucaklar:
            if ucak.ucak_numara == ucak_numara:
                print(f"{ucak.ucak_numara} numarali uçak bulundu: {ucak.marka_model}")
                return ucak
        print(f"{ucak_numara} numarali uçak bulunamadi.")
        return None

    def _askeri_guvenlik_protokolu(self):
        print("Askeri güvenlik protokolü devreye girdi.")
        sifre = input("Sifre giriniz:")
        girisdeneme = 3
        while girisdeneme:
            if sifre == "Hurkus":
                print("Hosgeldiniz...")
                break
            else:
                girisdeneme -= 1
                print(f"Giris deneme sayisi {girisdeneme} kaldi.")

    def _askeri_ucak_sorgusu(self):
        print("Askeri Uçak Sorgusu")
        print("1. Avci Uçaği Sorgusu")
        print("2. Askeri Helikopter Sorgusu")
        print("3. Bombardiman Uçaği Sorgusu")
        print("4. Nakliye Uçaği Sorgusu")
        print("5. Keşif Uçaği Sorgusu")
        
        secim = input("Sorgulamak istediğiniz askeri uçak türünü seçin (1-5): ")
        ucak_numara = input("Uçak numarasini girin: ")

        if secim == "1":
            ucak = self.ucak_arama(ucak_numara)
            if ucak:
                print(ucak.bilgileri_goster())
        elif secim == "2":
            ucak = self.ucak_arama(ucak_numara)
            if ucak:
                print(ucak.bilgileri_goster())
        elif secim == "3":
            ucak = self.ucak_arama(ucak_numara)
            if ucak:
                print(ucak.bilgileri_goster())
        elif secim == "4":
            ucak = self.ucak_arama(ucak_numara)
            if ucak:
                print(ucak.bilgileri_goster())
        elif secim == "5":
            ucak = self.ucak_arama(ucak_numara)
            if ucak:
                print(ucak.bilgileri_goster())
        else:
            print("Geçersiz seçim.")

    def _avci_ucagi_guvenlik(self, ucak):
        guvenlik_kodu = input("Lütfen avci uçaği için güvenlik kodunu giriniz: ")
        
        # Güvenlik kodunun kontrolü (örnek bir kod: "MAVERICK")
        if guvenlik_kodu == "MAVERICK":
            print("Güvenlik doğrulamasi başarili!")
            # Avcı uçağı bilgilerini gösterme
            print(ucak._bilgileri_goster())
            return True
        else:
            print("Geçersiz güvenlik kodu. Erişim reddedildi.")
            return False

    def _guzergah_kontrol(self, ucak, guzergah, hava_durumu):
        # sonradan kayıt edilecek guzergahlar icin şuan kullanılmayan guzelgah parametresi olması gerek.
        if isinstance(ucak, YolcuUcagi):
            #km/sa
            max_yan_ruzgar = 46
            min_yan_ruzgar = 5
            max_kuyruk_ruzgar = 28
            min_kuyruk_ruzgar = 0    
            max_bas_ruzgar = 65
            min_bas_ruzgar = 10
            min_sicaklik = -40
            max_sicaklik = 45
            min_gorunurluk = 800
            kabul_edilen_yagislar = ["Hafif", "Orta", "Yok"]
            hava_durumlari = ["Yagisli","Bulutlu","Gunesli","Sisli","Firtina","Karli"]

            ekstra_etmenler = (

            hava_durumu.hava_durumu in hava_durumlari
            and min_sicaklik <= hava_durumu.sicaklik <= max_sicaklik and 
            hava_durumu.gorunurluk >= min_gorunurluk and 
            hava_durumu.yagis_durumu in kabul_edilen_yagislar
            )
            uygun = (min_bas_ruzgar < hava_durumu.bas_ruzgar_hizi < max_bas_ruzgar and
                min_yan_ruzgar < hava_durumu.yan_ruzgar_hizi < max_yan_ruzgar and
                min_kuyruk_ruzgar < hava_durumu.kuyruk_ruzgar_hizi < max_kuyruk_ruzgar and ekstra_etmenler)

        elif isinstance(ucak, AskeriUcak):
            #km/sa
            max_yan_ruzgar = 35
            min_yan_ruzgar = 5
            max_kuyruk_ruzgar = 25
            min_kuyruk_ruzgar = 0
            max_bas_ruzgar = 60
            min_bas_ruzgar = 11
            min_sicaklik = -45
            max_sicaklik = 50
            min_gorunurluk = 500
            kabul_edilen_yagislar = ["Hafif", "Orta", "Yok"]
            hava_durumlari = ["Yagisli","Bulutlu","Gunesli","Sisli","Firtina","Karli"]
            
            ekstra_etmenler = (

            hava_durumu.hava_durumu in hava_durumlari and
            min_sicaklik <= hava_durumu.sicaklik <= max_sicaklik and 
            hava_durumu.gorunurluk >= min_gorunurluk and 
            hava_durumu.yagis_durumu in kabul_edilen_yagislar
            )
            uygun = (min_bas_ruzgar < hava_durumu.bas_ruzgar_hizi < max_bas_ruzgar and
                min_yan_ruzgar < hava_durumu.yan_ruzgar_hizi < max_yan_ruzgar and
                min_kuyruk_ruzgar < hava_durumu.kuyruk_ruzgar_hizi < max_kuyruk_ruzgar and ekstra_etmenler)
            
        elif isinstance(ucak, KargoUcagi):
            #km/sa
            max_yan_ruzgar = 40
            min_yan_ruzgar = 5
            max_kuyruk_ruzgar = 30
            min_kuyruk_ruzgar = 0
            max_bas_ruzgar = 70
            min_bas_ruzgar = 12
            min_sicaklik = -40
            max_sicaklik = 45
            min_gorunurluk = 600
            kabul_edilen_yagislar = ["Hafif", "Orta", "Yok"]
            hava_durumlari = ["Yagisli","Bulutlu","Gunesli","Sisli","Firtina","Karli"]

            ekstra_etmenler = (

            hava_durumu.hava_durumu in hava_durumlari and
            min_sicaklik <= hava_durumu.sicaklik <= max_sicaklik and 
            hava_durumu.gorunurluk >= min_gorunurluk and 
            hava_durumu.yagis_durumu in kabul_edilen_yagislar
            )
            uygun = (min_bas_ruzgar < hava_durumu.bas_ruzgar_hizi < max_bas_ruzgar and
                min_yan_ruzgar < hava_durumu.yan_ruzgar_hizi < max_yan_ruzgar and
                min_kuyruk_ruzgar < hava_durumu.kuyruk_ruzgar_hizi < max_kuyruk_ruzgar and ekstra_etmenler)

        # Sonuçları yazdır

        if uygun:
            print(f"{ucak.ucak_numara} için güzergah uygun.")
            islem_turu = input(f"{ucak.ucak_numara} icin 'kalkis' veya 'inis' seciniz: ").strip().lower()
    
            if islem_turu == "kalkis":
                self.__kalkis_izni_ver(ucak)
            elif islem_turu == "inis":
                self.__inis_izin_ver(ucak)
            else:
                print("Eksik veya hatali tuşlama yaptiniz. Lütfen 'kalkis' veya 'inis' giriniz.")
        else:
            print(f"{ucak.ucak_numara} için güzergah uygun değil.")

def main():
    # Ana program kısmı
    program_devam_ediyor = True

    # Uçak çeşitleri
    yolcu_ucagi = YolcuUcagi("THY123", "Boeing 737", 50000, 32000, 50, 18000, 180, "2+1")
    yolcu_ucagi_2 = YolcuUcagi("THY789", "Airbus A320", 45000, 30000, 45, 17000, 160, "3+3")
    yolcu_ucagi_3 = YolcuUcagi("ANA567", "Boeing 777", 70000, 45000, 55, 25000, 350, "3+4+3")
    kargo_ucagi = KargoUcagi("THY456", "Boeing 747", 440000, 280000, 80, 100000, 103000)
    kargo_ucagi_2 = KargoUcagi("UPS890", "Antonov An-124", 450000, 300000, 85, 120000, 150000)
    kargo_ucagi_3 = KargoUcagi("FEDEX321", "Lockheed C-5 Galaxy", 380000, 250000, 75, 90000, 140000)
    avci_ucagi = AvciUcagi("FELON", "SU-57", 35000, 18000, 80, 3500000, "Agir", 1, 1, 150, "Mach 2", "Yüksek", "Evet", "Füzeler, Makineli Tüfekler")
    avci_ucagi_2 = AvciUcagi("RAPTOR", "F-22", 38000, 20000, 90, 4000000, "Hafif", 1, 1, 160, "Mach 2.25", "Yüksek", "Evet", "Füzeler, Bombalar")
    avci_ucagi_3 = AvciUcagi("TYPHOON", "Eurofighter", 33000, 19000, 85, 3200000, "Orta", 1, 1, 140, "Mach 2", "Orta", "Evet", "Füzeler, Makineli Tüfekler")
    askeri_helikopter = AskeriHelikopter("BLACKHAWK", "UH-60", 12000, 8000, 75, 600000, "Orta", 4, 2, 50, "Yüksek", 23000, "Roketler, Makineli Tüfekler", 2000, "5 Saat")
    askeri_helikopter_2 = AskeriHelikopter("APACHE", "AH-64", 12000, 9000, 80, 450000, "Ağır", 2, 2, 60, "Yüksek", 15000, "Roketler, Makineli Tüfekler", 2500, "4 Saat")
    askeri_helikopter_3 = AskeriHelikopter("HIND", "Mi-24", 11000, 7000, 70, 380000, "Orta", 3, 2, 50, "Orta", 14000, "Roketler, Bombalar", 2000, "3 Saat")
    bombardiman_ucagi = BombardimanUcagi("SPIRIT", "B-2", 200000, 70000, 85, 10000000, "Ağır", 4, 2, 20000, 150, "Orta", "Elektronik Karıştırma", "Yüksek", "Mach 0.95")
    bombardiman_ucagi_2 = BombardimanUcagi("LANCER", "B-1", 230000, 85000, 90, 15000000, "Ağır", 4, 2, 25000, 170, "Yüksek", "Elektronik Karıştırma", "Orta", "Mach 1.25")
    bombardiman_ucagi_3 = BombardimanUcagi("FORTRESS", "B-29", 140000, 60000, 80, 8000000, "Orta", 5, 2, 18000, 120, "Düşük", "Radar Önleme", "Yüksek", "Mach 0.9")
    nakliye_ucagi = NakliyeUcagi("HERCULES", "C-130", 75000, 40000, 90, 8000000, "Ağır", 4, 2, 10, 5000, 2000, 500, 3000, 1000, 800, "600 km/s", "1500 m", "Orta")
    nakliye_ucagi_2 = NakliyeUcagi("GLOBEMASTER", "C-17", 135000, 76000, 95, 12000000, "Ağır", 4, 2, 15, 7500, 5000, 700, 3500, 2000, 1000, "850 km/s", "900 m", "Yüksek")
    nakliye_ucagi_3 = NakliyeUcagi("SPARTAN", "C-27J", 30000, 18000, 85, 3000000, "Hafif", 2, 2, 10, 1500, 1000, 300, 1200, 800, 400, "480 km/s", "500 m", "Orta")
    kesif_ucagi = KesifUcagi("GLOBALHAWK", "RQ-4", 15000, 10000, 95, 2200000, "Hafif", 2, 1, 300, "Kızılötesi, Termal", 500, "30 km, HD Çözünürlük")
    kesif_ucagi_2 = KesifUcagi("PREDATOR", "MQ-1", 1800, 1200, 90, 400000, "Hafif", 1, 1, 150, "Termal, Radyo Frekansı", 200, "25 km, HD Çözünürlük")
    kesif_ucagi_3 = KesifUcagi("PHANTOM", "RQ-3", 25000, 15000, 96, 2500000, "Orta", 2, 1, 400, "Kızılötesi, Elektronik Dinleme", 800, "50 km, UHD Çözünürlük")

    # Kontrol kulesi için nesne oluşturma
    kontrol_kulesi = KontrolKulesi()

    # Kuleye uçak ekleme
    kontrol_kulesi._ucak_ekle(yolcu_ucagi)
    kontrol_kulesi._ucak_ekle(kargo_ucagi)
    kontrol_kulesi._ucak_ekle(avci_ucagi)
    kontrol_kulesi._ucak_ekle(askeri_helikopter)
    kontrol_kulesi._ucak_ekle(bombardiman_ucagi)
    kontrol_kulesi._ucak_ekle(nakliye_ucagi)
    kontrol_kulesi._ucak_ekle(kesif_ucagi)
    kontrol_kulesi._ucak_ekle(yolcu_ucagi_2)
    kontrol_kulesi._ucak_ekle(kargo_ucagi_2)
    kontrol_kulesi._ucak_ekle(avci_ucagi_2)
    kontrol_kulesi._ucak_ekle(askeri_helikopter_2)
    kontrol_kulesi._ucak_ekle(bombardiman_ucagi_2)
    kontrol_kulesi._ucak_ekle(nakliye_ucagi_2)
    kontrol_kulesi._ucak_ekle(kesif_ucagi_2)
    kontrol_kulesi._ucak_ekle(yolcu_ucagi_3)
    kontrol_kulesi._ucak_ekle(kargo_ucagi_3)
    kontrol_kulesi._ucak_ekle(avci_ucagi_3)
    kontrol_kulesi._ucak_ekle(askeri_helikopter_3)
    kontrol_kulesi._ucak_ekle(bombardiman_ucagi_3)
    kontrol_kulesi._ucak_ekle(nakliye_ucagi_3)
    kontrol_kulesi._ucak_ekle(kesif_ucagi_3)

    # Güzergah nesneleri oluşturma
    guzergah1 = Guzergah("İstanbul - Ankara", 350, "Yolcu")
    guzergah2 = Guzergah("İstanbul - İzmir", 250, "Kargo")
    guzergah3 = Guzergah("İstanbul - Bağdat", 250, "Askeri")

    # hava durumu icin nesneler olusturma
    hava_durumu1 = HavaDurumu("Gunesli",25, 10, 15, 20, "Hafif",600, 0)
    hava_durumu2 = HavaDurumu("Gunesli", 10, 5, 20, 25, "Yok", 2000, 40)
    hava_durumu3 = HavaDurumu("Yagisli", 30, 10, 15, 15, "Hafif", 1500, 60)
    hava_durumu4 = HavaDurumu("Gunesli",25, 10, 30, 20, "Hafif",1000, 50)
    hava_durumu5 = HavaDurumu("Yagisli",10, 5, 20, 25, "Hafif",2000, 40)

    # Kuleden uçuş ekleme (Sivil Havacilik)
    kontrol_kulesi._ucus_ekle("Yolcu", "Boeing 737", "İstanbul-Ankara", [2024, 11, 20, 14, 30], [2024, 11, 20, 15, 30])
    kontrol_kulesi._ucus_ekle("Kargo", "Airbus A330", "Ankara-İzmir", [2024, 11, 20, 16, 0], [2024, 11, 20, 17, 30])
    kontrol_kulesi._ucus_ekle("Yolcu", "Boeing 737", "İstanbul-Ankara", [2024, 11, 20, 14, 30], [2024, 11, 20, 15, 30])
    kontrol_kulesi._ucus_ekle("Kargo", "Airbus A330", "İstanbul-Ankara", [2024, 11, 20, 15, 0], [2024, 11, 20, 16, 0])
    kontrol_kulesi._ucus_ekle("Yolcu", "Airbus A320", "İstanbul-Ankara", [2024, 11, 21, 16, 30], [2024, 11, 21, 17, 30])
    kontrol_kulesi._ucus_ekle("Yolcu", "Boeing 737", "İstanbul-İzmir", [2024, 11, 22, 14, 30], [2024, 11, 22, 15, 30])
    kontrol_kulesi._ucus_ekle("Kargo", "Airbus A330", "İstanbul-İzmir", [2024, 11, 23, 10, 30], [2024, 11, 23, 11, 30])

    #def ucus_ekle(self, ucak, ucak_tipi,guzergah, kalkis_saati, inis_saati):
    #kontrol_kulesi.ucus_ekle(guzergah1)
    #kontrol_kulesi.ucus_ekle(guzergah2)
    #kontrol_kulesi.ucus_ekle(guzergah3)
    print("\033[34mAvcı Uçağı Kodları : FELON, RAPTOR, TYPHOON\033[0m")
    print("\033[34mBombardıman Uçağı Kodları: SPIRIT, LANCER, FORTRESS\033[0m")
    print("\033[32mKeşif Uçağı Kodları: GLOBALHAWK, PREDATOR, PHANTOM\033[0m")
    print("\033[1;33mNakliye Uçak Kodları: HERCULES, GLOBEMASTER, SPARTAN\033[0m")
    print("\033[1;35mAskeri Helikopter Kodları: BLACKHAWK, APACHE, HIND\033[0m") 
    print("\033[31mAskeri Uçak Sorgu Şifresi: Hurkus\033[0m")  
    print("\033[31mAvcı Uçağı Sorgu Şifresi: MAVERICK\033[0m")
    while program_devam_ediyor:
  
        print("1. Sivil Uçak Sorgusu")
        print("2. Askeri Uçak Sorgusu")
        print("3. Sivil Havacilik Ucus Takvimi")
        print("4. Çikiş")
        
        secim = input("Seçiminizi yapin: ")
        
        if secim == "1":
            print("Sivil Havaciliğa Hoşgeldiniz...")
            while True:
                islem = input("Yapmak istediğiniz işlemi seçin: 'yolcu_ucak_arama', 'kargo_ucak_arama', 'guzergah_kontrol' veya 'geri' (Çikmak için '0' tuşlayiniz): ").strip().lower()
                
                if islem == "yolcu_ucak_arama":
                    ucak_numara = input("Aramak istediğiniz uçak numarasini giriniz: ").strip()
                    kontrol_kulesi.ucak_arama(ucak_numara)
                    
                    print(Ucak.ucak_bilgilerini_goster(ucak_numara))
                    print(YolcuUcagi.Ucak_Sayisi())

                if islem == "kargo_ucak_arama":
                    ucak_numara = input("Aramak istediğiniz uçak numarasini giriniz: ").strip()
                    kontrol_kulesi.ucak_arama(ucak_numara)
                    
                    print(Ucak.ucak_bilgilerini_goster(ucak_numara))
                    print(KargoUcagi.Ucak_Sayisi())
                
                
                elif islem == "guzergah_kontrol":
                    print("\nYolcu Uçaği için hava durumu ve güzergah kontrolü yapiliyor:")
                    hava_durumu1 = HavaDurumu("Güneşli", 25, 10, 15, 20, "Hafif", 600, 0)
                    kontrol_kulesi._guzergah_kontrol(yolcu_ucagi, guzergah1, hava_durumu1)
                    kontrol_kulesi._guzergah_kontrol(yolcu_ucagi_2, guzergah1, hava_durumu4)
                    kontrol_kulesi._guzergah_kontrol(yolcu_ucagi_3, guzergah1, hava_durumu4)


                    print("\nKargo Uçaği için hava durumu ve güzergah kontrolü yapiliyor:")
                    hava_durumu2 = HavaDurumu("Güneşli", 10, 5, 20, 25, "Yok", 2000, 40)
                    kontrol_kulesi._guzergah_kontrol(kargo_ucagi, guzergah2, hava_durumu2)
                    kontrol_kulesi._guzergah_kontrol(kargo_ucagi_2, guzergah2, hava_durumu5)
                    kontrol_kulesi._guzergah_kontrol(kargo_ucagi_3, guzergah2, hava_durumu5)



                elif islem == "geri":
                    print("Ana menüye dönülüyor...")
                    break

                elif islem == "0":
                    print("Program Sonlandi. Tekrar görüşmek üzere...")
                    program_devam_ediyor = False
                    break

                else:
                    print("Lütfen geçerli bir seçenek giriniz.")

        elif secim == "2":
            kontrol_kulesi._askeri_guvenlik_protokolu()
            print("Askeri Havaciliğa Hoşgeldiniz...")
            print("Askeri Uçak Sorgusu")
            print("1. Avci Uçaği Sorgusu")
            print("2. Askeri Helikopter Sorgusu")
            print("3. Bombardiman Uçaği Sorgusu")
            print("4. Nakliye Uçaği Sorgusu")
            print("5. Keşif Uçaği Sorgusu")
        
            secim_ucak = input("Sorgulamak istediğiniz askeri uçak türünü seçin (1-5): ")

            # Uçak sorgulama ve uygunluk kontrolü
            if secim_ucak == "1":
                ucak_numara = input("Uçak numarasini girin: ")
                ucak = kontrol_kulesi.ucak_arama(ucak_numara)
                if ucak:
                    # Güvenlik kontrolü
                    kontrol_kulesi._avci_ucagi_guvenlik(ucak)
                # Ucak Bilgileri Goster
                print(avci_ucagi._bilgileri_goster())  
                # Uygunluk kontrolü
                kontrol_kulesi._guzergah_kontrol(ucak, guzergah3,hava_durumu3)  # Guzergah3 askeri

            elif secim_ucak == "2":
                ucak_numara = input("Uçak numarasini girin: ")
                ucak = kontrol_kulesi.ucak_arama(ucak_numara)
                if ucak:
                    print(askeri_helikopter._bilgileri_goster())
                    # Uygunluk kontrolü
                    kontrol_kulesi._guzergah_kontrol(ucak, guzergah3, hava_durumu3)  # Guzergah3 askeri
                else:
                    print("Belirtilen uçak numarasiyla eşleşen bir uçak bulunamadi.")
            elif secim_ucak == "3":
                ucak_numara = input("Uçak numarasini girin: ")
                ucak = kontrol_kulesi.ucak_arama(ucak_numara)
                if ucak:
                    print(bombardiman_ucagi._bilgileri_goster())
                    # Uygunluk kontrolü
                    kontrol_kulesi._guzergah_kontrol(ucak, guzergah3, hava_durumu3)  # Guzergah3 askeri
                else:
                    print("Belirtilen uçak numarasiyla eşleşen bir uçak bulunamadi.")
            elif secim_ucak == "4":
                ucak_numara = input("Uçak numarasini girin: ")
                ucak = kontrol_kulesi.ucak_arama(ucak_numara)
                if ucak:
                    print(nakliye_ucagi._bilgileri_goster())
                    # Uygunluk kontrolü
                    kontrol_kulesi._guzergah_kontrol(ucak, guzergah3, hava_durumu3)  # Guzergah3 askeri
                else:
                    print("Belirtilen uçak numarasiyla eşleşen bir uçak bulunamadi.")
            elif secim_ucak == "5":
                ucak_numara = input("Uçak numarasini girin: ")
                ucak = kontrol_kulesi.ucak_arama(ucak_numara)
                if ucak:
                    print(kesif_ucagi._bilgileri_goster())
                    # Uygunluk kontrolü
                    kontrol_kulesi._guzergah_kontrol(ucak, guzergah3, hava_durumu3)  # Guzergah3 askeri
                else:
                    print("Belirtilen uçak numarasiyla eşleşen bir uçak bulunamadi.")
            else:
                print("Geçersiz seçim.")

        elif secim == "3":
            print("Sivil Havacilik Ucus Takvimi:")
            kontrol_kulesi._ucuslari_goster()      
        
        elif secim == "4":
            break
        else:
            print("Geçersiz seçim.")

    print("Program Sonlandi. Tekrar görüşmek üzere...")

main()